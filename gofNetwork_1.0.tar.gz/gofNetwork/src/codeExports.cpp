

#include <RcppArmadillo.h>
#include <Rcpp.h>

using namespace Rcpp;
using namespace arma;

List vbem(const mat& Y, const NumericVector& X, int n, int K, int d, const mat& Z, const mat& connect, mat& xi, double e0, double a0, double b0, double c0, double d0, int maxit, double epsconv);

RcppExport SEXP gofNetwork_vbem(SEXP SEXPY, SEXP SEXPX, SEXP SEXPn, SEXP SEXPK, SEXP SEXPd, SEXP SEXPZ, SEXP SEXPconnect, SEXP SEXPxi, SEXP SEXPe0, SEXP SEXPa0, SEXP SEXPb0, SEXP SEXPc0, SEXP SEXPd0, SEXP SEXPmaxit, SEXP SEXPepsconv) {

  mat Y = as<mat>(SEXPY);
  NumericVector X = as<NumericVector>(SEXPX);
  int n = as<int>(SEXPn);
  int K = as<int>(SEXPK);
  int d = as<int>(SEXPd);
  mat Z = as<mat>(SEXPZ);
  mat connect = as<mat>(SEXPconnect);
  mat xi = as<mat>(SEXPxi);
  double e0 = as<double>(SEXPe0);
  double a0 = as<double>(SEXPa0);
  double b0 = as<double>(SEXPb0);
  double c0 = as<double>(SEXPc0);
  double d0 = as<double>(SEXPd0);
  int maxit = as<int>(SEXPmaxit);
  double epsconv = as<double>(SEXPepsconv);

  return(wrap( vbem(Y, X, n, K, d, Z, connect, xi, e0, a0, b0, c0, d0, maxit, epsconv) ));
}



List vbemundirected(const mat& Y, const NumericVector& X, int n, int K, int d, const mat& Z, const mat& connect, mat& xi, double e0, double a0, double b0, double c0, double d0, int maxit, double epsconv);

RcppExport SEXP gofNetwork_vbemundirected(SEXP SEXPY, SEXP SEXPX, SEXP SEXPn, SEXP SEXPK, SEXP SEXPd, SEXP SEXPZ, SEXP SEXPconnect, SEXP SEXPxi, SEXP SEXPe0, SEXP SEXPa0, SEXP SEXPb0, SEXP SEXPc0, SEXP SEXPd0, SEXP SEXPmaxit, SEXP SEXPepsconv) {

  mat Y = as<mat>(SEXPY);
  NumericVector X = as<NumericVector>(SEXPX);
  int n = as<int>(SEXPn);
  int K = as<int>(SEXPK);
  int d = as<int>(SEXPd);
  mat Z = as<mat>(SEXPZ);
  mat connect = as<mat>(SEXPconnect);
  mat xi = as<mat>(SEXPxi);
  double e0 = as<double>(SEXPe0);
  double a0 = as<double>(SEXPa0);
  double b0 = as<double>(SEXPb0);
  double c0 = as<double>(SEXPc0);
  double d0 = as<double>(SEXPd0);
  int maxit = as<int>(SEXPmaxit);
  double epsconv = as<double>(SEXPepsconv);

  return(wrap( vbemundirected(Y, X, n, K, d, Z, connect, xi, e0, a0, b0, c0, d0, maxit, epsconv) ));
}


