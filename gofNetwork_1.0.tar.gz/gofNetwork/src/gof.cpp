#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;


double logistic(double & x) {
  return( 1/(1+exp(-x)) );
}

double absvalue(double  x) {
  if(x<0) {
    return(-x);
  }
  else{
    return(x);
  }
}

double lambda(double & x) {
  return( (logistic(x) - 0.5)/(2*x) ) ;
}

// [[Rcpp::export]]
List vbem(const mat& Y, const NumericVector& X, int n, int K, int d, const mat& Z, const mat& connect, mat& xi, double e0, double a0, double b0, double c0, double d0, int maxit, double epsconv) {
    
  IntegerVector dim = X.attr("dim");
  cube XC(X.begin(), dim[0], dim[1], dim[2]); // transform array into cube
  
  int ite=0, i, j, K2=K*K, k, l, ide, checkconv=0;
  mat xij;
  
  mat tau = Z;
  NumericVector en(K);
  double an=a0, bn=b0, cn=c0, dn=d0;
  mat malpha = connect; 
  
  mat SbetaINV, Sbeta, mbeta;
  mat SalphaINV, Salpha, malphavec, Sa, Ealpha2;
  
  mat xiold;
  
  double eps = DBL_MIN;
  
  mat lbound(maxit, 1);
  
  while((ite<maxit) & (checkconv==0)) { // keep going until convergence or maximum number of iterations reached

    // q(pi)
    en = e0 + sum(tau, 0); 
    
    // q(beta)
    SbetaINV = eye<mat>(d,d)*cn/dn;
    mbeta = zeros<mat>(d, 1);
    
    for(i=0; i<n; i++){
      for(j=0; j<n; j++) {
        if(i != j) {
          xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
          xij = xij.t();
          SbetaINV = SbetaINV + 2*lambda(xi(i, j))*xij*xij.t();
          mbeta = mbeta + xij*(Y(i,j) - 0.5 - 2*lambda(xi(i,j))*tau.row(i)*malpha*(tau.row(j).t()));    
        }
      }
    }
    Sbeta = inv(SbetaINV);
    mbeta = Sbeta*mbeta;
    
    // q(alpha)
    // be careful : SalphaINV is a vector to speed up calculations. In theory : Salpha and SalphaINV  are DIAGONAL matrices
    SalphaINV = ones<mat>(K2,1)*an/bn;
    malphavec = zeros<mat>(K2, 1); 
    for(i=0; i<n; i++) {
      for(j=0; j<n; j++) {
        if(i != j) {
          xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
          xij = xij.t();
          for(k=0; k<K; k++) { // SalphaINV is organised by blocks !
          for(l=0; l<K; l++) {
            ide = l*K + k;
            SalphaINV(ide, 0) = SalphaINV(ide, 0)  + 2*lambda(xi(i,j))*tau(i,k)*tau(j,l);
          }
          }
          mat krij = (kron(tau.row(j), tau.row(i))).t();
          malphavec = malphavec + krij*(Y(i, j) - 0.5 - 2*lambda(xi(i, j))*xij.t()*mbeta);
        }
      }
    }
    Salpha = 1 / SalphaINV; // element wise division
    malphavec = Salpha % malphavec; // element wise multiplication 
    Sa = Salpha;
    Sa.set_size(K, K); // convert vector into matrix
    
    malpha = malphavec;
    malpha.set_size(K, K); // convert vector into matrix 
    
    Ealpha2 = Sa + malpha % malpha;
       
    // compute lower bound
    lbound(ite, 0) = 0;
    for(i=0; i<n; i++) {
      for(j=0; j<n; j++) {
        if(i != j) {
          lbound(ite, 0) += log(logistic(xi(i,j))) - 0.5*xi(i,j) + lambda(xi(i,j))*xi(i,j)*xi(i,j);
        }
      }
    }
    
    for(k=0; k<K; k++) {
      lbound(ite, 0) += lgamma(en(k)) - lgamma(e0);
    }
    lbound(ite, 0) += lgamma(e0*K) - lgamma(sum(en)) + lgamma(an) - lgamma(a0) + lgamma(cn) - lgamma(c0) + a0*log(b0);
    lbound(ite, 0) += an*(1-b0/bn - log(bn)) + c0*log(d0) + cn*(1-d0/dn-log(dn));
    lbound(ite, 0) += (0.5)*sum(sum(log(Salpha))) + (0.5)*log(det(Sbeta)) - sum(sum(tau % log(tau)));
    lbound(ite, 0) += (0.5)*sum(sum(SalphaINV % malphavec % malphavec));
    lbound(ite, 0) += -(0.5)*as_scalar(mbeta.t()*SbetaINV*mbeta);
    
    
    mat tmp;
    tmp=zeros<mat>(d, 1);
    for(i=0; i<n; i++) {
      for(j=0; j<n; j++) {
        if(i != j) {
          xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
          xij = xij.t();
          tmp = tmp + (Y(i,j)-0.5)*xij;
        }
      }
    }
    lbound(ite, 0) += as_scalar(mbeta.t()*tmp);
   
    // check convergence ..
     if(ite>0) {
       //if(sum(sum(abs(xi - xiold))) <= epsconv) { // check convergence on the parameters ..
       double lboundnew = lbound(ite, 0), lboundold = lbound(ite-1, 0);
      // absvalue
       if(absvalue(lboundnew-lboundold) <= epsconv) { // check convergence of the lower bound ..}
         checkconv = 1;               
        // break;
       }
     }
     xiold = xi; 
    
    // q(gamma)
    an = a0 + K2*0.5;
    bn = b0 + (0.5)*sum(sum(Salpha)) + (0.5)*as_scalar(malphavec.t()*malphavec);

    
    // q(eta)
    cn = c0 + d*0.5;
    dn = d0 + (0.5)*trace(Sbeta) + (0.5)*as_scalar(mbeta.t()*mbeta);
    
    // xi : local optimization
    for(i=0; i<n; i++) {
      for(j=0; j<n; j++) {
        if(i != j) {
          xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
          xij = xij.t();
          xi(i,j) = 0;
          for(k=0; k<K; k++) {
            for(l=0; l<K; l++) {
              ide = l*K + k;
              xi(i,j) = xi(i,j) + (Salpha(ide, 0) + malphavec(ide, 0)*malphavec(ide, 0))*tau(i,k)*tau(j,l);
            }
          }
          xi(i,j) = xi(i,j) + 2*as_scalar(tau.row(i)*malpha*(tau.row(j).t())*xij.t()*mbeta);
          xi(i,j) = xi(i,j) + trace( xij*xij.t()*( Sbeta + mbeta*mbeta.t() ) ); 
          xi(i,j) = sqrt(xi(i,j));
        }
      }
    }
    
    // q(Z) 
    for(i=0; i<n; i++) {
      for(k=0; k<K; k++) {
        tau(i, k) = 0;
        for(j=0; j<n; j++) {
          if(i != j) {
            xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
            xij = xij.t();
            double tmpj = Y(i,j) - 0.5 - 2*as_scalar(lambda(xi(i,j))*xij.t()*mbeta);
            tau(i, k) = tau(i, k) + tmpj*sum(sum(malpha.row(k) % tau.row(j))); 
                  
            tau(i, k) = tau(i, k) - lambda(xi(i,j))*sum(sum(Ealpha2.row(k) % tau.row(j)));
            
            
            xij = XC.subcube(j, i, 0, j, i, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
            xij = xij.t();
            tmpj = Y(j,i) - 0.5 - 2*as_scalar(lambda(xi(j,i))*xij.t()*mbeta);
            tau(i, k) = tau(i, k) + tmpj*sum(sum((malpha.col(k)).t() % tau.row(j))); 
            
            tau(i, k) = tau(i, k) - lambda(xi(j,i))*sum(sum((Ealpha2.col(k)).t() % tau.row(j)));
              
          }
        }
        tau(i, k) = tau(i, k) + Rf_digamma(en(k)) - Rf_digamma((sum(en)));
      }

      tau.row(i) = tau.row(i) - max(tau.row(i));
      tau.row(i) = exp(tau.row(i));
      tau.row(i) = tau.row(i) / sum(tau.row(i));
      
      // avoid numerical issues : tauik too close to zero ..
      for(k=0; k<K; k++) {
        if(tau(i, k)<eps) {
          tau(i, k) = eps;
        } 
      }
    }
    
    
    ite++; 
  }

  
  /*if(checkconv == 0) { // no convergence : maximum number of iterations reached ..
    std::cout<< "!!! maximum number of iterations reached !!!" << std::endl;
  }
  else{
    std::cout<< "GOF (directed) (" << K << " clusters) " << "converged in " << ite << " iterations" << std::endl;
    }*/
  
  List res;
  res["lbound"] = lbound.submat(0, 0, ite-1, 0);
  res["criterion"] = lbound(ite-1, 0);
  res["tau"] = tau;
  res["tau0"] = Z;
  res["xi"] = xi;
  res["en"] = en;
  res["an"] = an;
  res["bn"] = bn;
  res["cn"] = cn;
  res["dn"] = dn;
  res["malpha"] = malpha;
  res["Salpha"] = Salpha;
  res["mbeta"] = mbeta;
  res["Sbeta"] = Sbeta;  
  
  
  return(res);
  
  
 // return List::create(
  //  lbound.submat(0, 0, ite-1, 0),  Z, xi, en, an, bn, cn, dn);
  
}


// [[Rcpp::export]]
List vbemundirected(const mat& Y, const NumericVector& X, int n, int K, int d, const mat& Z, const mat& connect, mat& xi, double e0, double a0, double b0, double c0, double d0, int maxit, double epsconv) {
     
  IntegerVector dim = X.attr("dim");
  cube XC(X.begin(), dim[0], dim[1], dim[2]); // transform array into cube
  
  int ite=0, i, j, K2=K*(K+1)/2, k, l, checkconv=0; // #!#
  mat xij;
  
  mat tau = Z;
  NumericVector en(K);
  double an=a0, bn=b0, cn=c0, dn=d0;
  mat malpha = connect; 
 
  mat SbetaINV, Sbeta, mbeta;
  mat SalphaINV, Salpha, Sa, Ealpha2;
  
  mat xiold;
  
  double eps = DBL_MIN;
  
  mat lbound(maxit, 1);
  
  while((ite<maxit) & (checkconv==0)) { // keep going until convergence or maximum number of iterations reached

    // q(pi)
    en = e0 + sum(tau, 0); 
    
    // q(beta)
    SbetaINV = eye<mat>(d,d)*cn/dn;
    mbeta = zeros<mat>(d, 1);
    
    for(i=0; i<n; i++){
      for(j=0; j<n; j++) {
        if(i != j) {
          xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
          xij = xij.t();
          SbetaINV = SbetaINV + lambda(xi(i, j))*xij*xij.t(); // #!#
          mbeta = mbeta + xij*(Y(i,j) - 0.5 - 2*lambda(xi(i,j))*tau.row(i)*malpha*(tau.row(j).t()));    
        }
      }
    }
    Sbeta = inv(SbetaINV);
    mbeta = Sbeta*mbeta*0.5; // #!#
    
    // q(alpha)
    // #!#
    SalphaINV = ones<mat>(K,K)*an/bn;
      
    malpha = zeros<mat>(K, K)*0.0; 
    for(k=0; k<K; k++) {
      for(i=0; i<n; i++) {
        for(j=0; j<n; j++) {
          if(i != j) {
            xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
            xij = xij.t();
            SalphaINV(k, k) = SalphaINV(k, k) + lambda(xi(i,j))*tau(i,k)*tau(j,k); 
            malpha(k, k) = malpha(k, k) + (0.5*(Y(i, j) - 0.5) - lambda(xi(i, j))*as_scalar(xij.t()*mbeta))*tau(i,k)*tau(j,k);
          }   
        }
      }
    }
    for(k=0; k<K; k++) {
      for(l=k+1; l<K; l++) {
        for(i=0; i<n; i++) {
          for(j=0; j<n; j++) {
            if(i != j) {
              xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
              xij = xij.t();
              SalphaINV(k, l) = SalphaINV(k, l) + 2*lambda(xi(i,j))*tau(i,k)*tau(j,l); 
              malpha(k, l) = malpha(k, l) + (Y(i, j) - 0.5 - 2*lambda(xi(i, j))*as_scalar(xij.t()*mbeta))*tau(i,k)*tau(j,l);
            }   
          }
        }
        SalphaINV(l, k) = SalphaINV(k, l);
        malpha(l, k) = malpha(k, l);
        
      }
    }
    Salpha = 1 / SalphaINV; // element wise division
    malpha = Salpha % malpha; // element wise multiplication 
    Sa = Salpha;
    
    Ealpha2 = Sa + malpha % malpha;
       
    // compute lower bound
    lbound(ite, 0) = 0;
    for(i=0; i<n; i++) {
      for(j=0; j<n; j++) {
        if(i != j) {
          lbound(ite, 0) += log(logistic(xi(i,j))) - 0.5*xi(i,j) + lambda(xi(i,j))*xi(i,j)*xi(i,j);
        }
      }
    }
    lbound(ite, 0) = lbound(ite, 0)*0.5; // #!#
    for(k=0; k<K; k++) {
      lbound(ite, 0) += lgamma(en(k)) - lgamma(e0);
    }
    lbound(ite, 0) += lgamma(e0*K) - lgamma(sum(en)) + lgamma(an) - lgamma(a0) + lgamma(cn) - lgamma(c0) + a0*log(b0);
    lbound(ite, 0) += an*(1-b0/bn - log(bn)) + c0*log(d0) + cn*(1-d0/dn-log(dn));
    
    //lbound(ite, 0) += (0.5)*sum(sum(log(Salpha))) + (0.5)*log(det(Sbeta)) - sum(sum(tau % log(tau)));
    //lbound(ite, 0) += (0.5)*sum(sum(SalphaINV % malphavec % malphavec));
    
    lbound(ite, 0) += (0.5)*sum(sum(trimatu(log(Salpha)))) + (0.5)*log(det(Sbeta)) - sum(sum(tau % log(tau))); // #!#
    lbound(ite, 0) += (0.5)*sum(sum(trimatu(SalphaINV % malpha % malpha))); // #!#
    
    lbound(ite, 0) += -(0.5)*as_scalar(mbeta.t()*SbetaINV*mbeta);
    
    
    mat tmp;
    tmp=zeros<mat>(d, 1);
    for(i=0; i<n; i++) {
      for(j=0; j<n; j++) {
        if(i != j) {
          xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
          xij = xij.t();
          tmp = tmp + (Y(i,j)-0.5)*xij;
        }
      }
    }
    lbound(ite, 0) += as_scalar(mbeta.t()*tmp)*0.5; // #!#
   
    // check convergence ..
     if(ite>0) {
       //if(sum(sum(abs(xi - xiold))) <= epsconv) { // check convergence on the parameters ..
       double lboundnew = lbound(ite, 0), lboundold = lbound(ite-1, 0);
      // absvalue
       if(absvalue(lboundnew-lboundold) <= epsconv) { // check convergence of the lower bound ..}
         checkconv = 1;               
        // break;
       }
     }
     xiold = xi; 
    
    // q(gamma)
    an = a0 + K2*0.5;
   // bn = b0 + (0.5)*sum(sum(Salpha)) + (0.5)*as_scalar(malphavec.t()*malphavec);
    bn = b0 + (0.5)*sum(sum(trimatu(Ealpha2))); // #!#
    
    // q(eta)
    cn = c0 + d*0.5;
    dn = d0 + (0.5)*trace(Sbeta) + (0.5)*as_scalar(mbeta.t()*mbeta);
    
    // xi : local optimization
    for(i=0; i<n; i++) {
      for(j=0; j<n; j++) {
        if(i != j) {
          xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
          xij = xij.t();
          xi(i,j) = 0;
          for(k=0; k<K; k++) {
            for(l=0; l<K; l++) {
              //ide = l*K + k;
              //xi(i,j) = xi(i,j) + (Salpha(ide, 0) + malphavec(ide, 0)*malphavec(ide, 0))*tau(i,k)*tau(j,l);
              xi(i,j) = xi(i,j) + Ealpha2(k, l)*tau(i,k)*tau(j,l); // #!#
            }
          }
          xi(i,j) = xi(i,j) + 2*as_scalar(tau.row(i)*malpha*(tau.row(j).t())*xij.t()*mbeta);
          xi(i,j) = xi(i,j) + trace( xij*xij.t()*( Sbeta + mbeta*mbeta.t() ) ); 
          xi(i,j) = sqrt(xi(i,j));
        }
      }
    }
    
    // q(Z) 
    for(i=0; i<n; i++) {
      for(k=0; k<K; k++) {
        tau(i, k) = 0;
        for(j=0; j<n; j++) {
          if(i != j) {
            xij = XC.subcube(i, j, 0, i, j, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
            xij = xij.t();
            double tmpj = Y(i,j) - 0.5 - 2*as_scalar(lambda(xi(i,j))*xij.t()*mbeta);
            tau(i, k) = tau(i, k) + tmpj*sum(sum(malpha.row(k) % tau.row(j))); 
                  
            tau(i, k) = tau(i, k) - lambda(xi(i,j))*sum(sum(Ealpha2.row(k) % tau.row(j)));
            
            
            xij = XC.subcube(j, i, 0, j, i, d-1); // first_row, first_col, first_slice, last_row, last_col, last_slice
            xij = xij.t();
            tmpj = Y(j,i) - 0.5 - 2*as_scalar(lambda(xi(j,i))*xij.t()*mbeta);
            tau(i, k) = tau(i, k) + tmpj*sum(sum((malpha.col(k)).t() % tau.row(j))); 
            
            tau(i, k) = tau(i, k) - lambda(xi(j,i))*sum(sum((Ealpha2.col(k)).t() % tau.row(j)));
              
          }
        }
        tau(i, k) = tau(i, k)*0.5; // #!#
        tau(i, k) = tau(i, k) + Rf_digamma(en(k)) - Rf_digamma((sum(en)));
      }

      tau.row(i) = tau.row(i) - max(tau.row(i));
      tau.row(i) = exp(tau.row(i));
      tau.row(i) = tau.row(i) / sum(tau.row(i));
      
      // avoid numerical issues : tauik too close to zero ..
      for(k=0; k<K; k++) {
        if(tau(i, k)<eps) {
          tau(i, k) = eps;
        } 
      }
    }
    
    ite++; 
  }
  /*
  if(checkconv == 0) { // no convergence : maximum number of iterations reached ..
    std::cout<< "!!! maximum number of iterations reached !!!" << std::endl;
  }
  else{
    std::cout<< "GOF (undirected) (" << K << " clusters) " << "converged in " << ite << " iterations" << std::endl;
    }*/
  
  List res;
  res["lbound"] = lbound.submat(0, 0, ite-1, 0);
  res["criterion"] = lbound(ite-1, 0);
  res["tau"] = tau;
  res["tau0"] = Z;
  res["xi"] = xi;
  res["en"] = en;
  res["an"] = an;
  res["bn"] = bn;
  res["cn"] = cn;
  res["dn"] = dn;
  res["malpha"] = malpha;
  res["Salpha"] = Salpha;
  res["mbeta"] = mbeta;
  res["Sbeta"] = Sbeta;  
  
  
  return(res);
  
  
 // return List::create(
  //  lbound.submat(0, 0, ite-1, 0),  Z, xi, en, an, bn, cn, dn);
  
}











