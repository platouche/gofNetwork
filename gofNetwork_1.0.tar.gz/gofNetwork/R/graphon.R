

computegraphon<-function(x, L=50, priorModel=c(1/2, rep(1/2, x$qmax-1)/(x$qmax-2+1)), nbsim=1000, prob=TRUE) {
  if(x$qmin>1) {
    stop("computegraphon must be run with qmin=1")
  }
  if(x$directed == TRUE) {
    stop("graphon estimation only for undirected networks")
  }
  U<-seq(0, 1, length=L)
  V<-seq(0, 1, length=L)
  meanphi<-matrix(0, L, L)
  pr<-computeProbBayes(x, priorModel=priorModel)
  post<-pr$post
  qmax<-x$qmax
  for(k in 1:qmax) {
    cat("Graphon estimation for k=", k, "..\n")
    if(is.gofNetwork(x)){
      a<-x$output[[k]]$en
      alphahat<-plogis(x$output[[k]]$malpha)
    }
    if(is.mixer(x)){
      a<-x$output[[k]]$a
      alphahat<-x$output[[k]]$Pis
    }
    
    if(k == 1) {
      alphahat_1 = alphahat
    }
    pihat<-a/sum(a)
    ord<-order(pihat%*%alphahat)
    
    a<-a[ord]
    alphahat<-alphahat[ord, ord]
    
    if(prob=="FALSE") {
      alphahat = qlogis(alphahat)
    }
    
    zzz<-jointPosterior(U, V, a, nbsim)
    jpost<-zzz$jpost
    
    for(u in 1:L) {
      for(v in u:L){
        meanphi[u, v]<-meanphi[u, v]+sum(alphahat[upper.tri(alphahat, diag=TRUE)]*jpost[u, v, ] )*post[k]
        meanphi[v, u]<-meanphi[u, v]  
      }  
    }  
  }
  
  if(abs(max(meanphi) - min(meanphi))/abs(min(meanphi))<1e-1) { # the tiny differences in the graphon make the wireframe plot of lattice very hard to read
    best<-getModel(x)
    if(best$q == 1) { # the model probabilities pick at 1 cluster only
      meanphi<-matrix(alphahat_1, L, L)
    }
  }
  return(list(graphon=meanphi, post=post, grid=U))
  
}


jointPosterior <- function(U, V, alpha, nbsim=1000) {
  
  K<-length(alpha) # number of classes
  N<-length(U) # size of the grid : N*N
  
  # Monte Carlo ..
  S=nbsim
  X = matrix(0, S, K)
  for (j in (1:K))
  {X[,j] = rgamma(S, shape=alpha[j])
  }
  X = X/rowSums(X)
  Xcum = t(apply(X, 1, cumsum))
  jpost<-array(0, dim=c(N, N, K*(K+1)/2))
  
  for(u in 1:N) {
    for(v in u:N){
      Ruvkl<-matrix(0, K, K)
      for(k in 1:K) {
        kboundLeft = Xcum[, k-1]
        kboundRight = Xcum[, k]
        if(k==1) {
          kboundLeft = 0
        }
        else if(k==K) {
          kboundRight = 1
        }
        for(l in k:K) {
          lboundLeft = Xcum[, l-1]
          lboundRight = Xcum[, l]
          if(l==1){
            lboundLeft = 0
          }
          else if(l==K) {
            lboundRight = 1
          }
          
          Ruvkl[k, l] = sum((kboundLeft<=U[u])*(U[u]<=kboundRight)*(lboundLeft<=V[v])*(V[v]<=lboundRight))/S
        }
      }
      jpost[u, v, ]<-Ruvkl[upper.tri(Ruvkl, diag=TRUE)]   
    }
  }
  return(list(jpost=jpost, X=X, Xcum=Xcum))
}


