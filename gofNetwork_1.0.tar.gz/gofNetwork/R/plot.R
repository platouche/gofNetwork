
############################################################
# Plot the reorganized adjacency matrix
############################################################

plotam<-function(edges,cluster)
{
  neworder<-order(cluster)
  max(edges)->n
  m<-t(matrix(order(neworder)[as.numeric(edges)],2))
  plot(1, 1, xlim = c(0, n + 1), ylim = c(n + 1, 0), type = "n", axes= FALSE,xlab="classes",ylab="classes",main="Reorganized Adjacency matrix")
  rect(m[,2]-0.5,m[,1]-0.5,m[,2]+0.5,m[,1]+0.5,col=1)
  rect(m[,1]-0.5,m[,2]-0.5,m[,1]+0.5,m[,2]+0.5,col=1)
  table(cluster)->limits # find the class limits
  cumsum(limits)[1:(length(limits)-1)]+0.5->limits
  abline(v=c(0.5,limits,n+0.5),h=c(0.5,limits,n+0.5),col="red")
}

plot.gofNetwork<-function(x){

  # Test x
  if (!is.gofNetwork( x ))
    stop("Not a gofNetwork object")
  
  resQ<-getModel(x)
  
  cl<-apply(resQ$output$tau, 1, which.max)
  par(mfrow=c(1, 2))

  tmp<-boxplot(x$criterion, names=(x$qmin):(x$qmax), main="model posterior probabilities")
  plotam(x$edges, cl)
  
}


plot.graphon<-function(x, zlim=NULL){
  
 # plot(wireframe(x$graphon, shade = TRUE, light.source = c(3,3,3), aspect = c(61/87, 0.4),  zlim=c(0,1), xlab="", ylab="", zlab="", par.settings = list(axis.line = list(col = "transparent"))))
  if(is.null(zlim)) {
    plot(wireframe(x$graphon, shade = TRUE, light.source = c(3,3,3), aspect = c(61/87, 0.4),  xlab="", ylab="", zlab="", par.settings = list(axis.line = list(col = "transparent"))))
  }
  else {
    plot(wireframe(x$graphon, shade = TRUE, light.source = c(3,3,3), aspect = c(61/87, 0.4),  xlab="", ylab="", zlab="", zlim=zlim, par.settings = list(axis.line = list(col = "transparent"))))
  }
}
