

gof_base<-function(Y, X, K, d, maxit=100, epsconv=1e-8, directed=(sum(abs(Y-t(Y)))>0)) {
  
  n<-dim(Y)[1]
  
  res<-mixer(Y, qmin=K, qmax=K, method="bayesian", verbose=FALSE, directed=directed)
  tau0<-t(res$output[[1]]$Taus)
  connect<-qlogis(res$output[[1]]$Pis)
  connect[connect>2]<-2
  connect[connect< (-2)]<--2
  
  tau0[tau0<.Machine$double.xmin] <- .Machine$double.xmin
  tau0[tau0> 1/(1+.Machine$double.eps)] <- 1/(1+.Machine$double.eps)
  
  xi<-matrix(0.001, n, n)
  diag(xi)<-0
  
  e0<-1
  a0<-1
  b0<-1
  c0<-1
  d0<-1

  if(directed) {
    rescpp<-vbem(Y, X, n, K, d, tau0, as.matrix(connect), xi, e0, a0, b0, c0, d0, maxit, epsconv) 
  }else{
    rescpp<-vbemundirected(Y, X, n, K, d, tau0, as.matrix(connect), xi, e0, a0, b0, c0, d0, maxit, epsconv) 
  }
  
  if(length(which(diff(rescpp$lbound)< -1e-3))>0) warning(paste("warning : lower bound has decreased (diff < ", min(diff(rescpp$lbound)),") at some point for K=", K))

  return(rescpp)
  
}

gofK<-function(Y, X, d, qmin, qmax, maxit=100, epsconv=1e-8, directed=(sum(abs(Y-t(Y)))>0))  {
  
  res<-list(Y=Y, X=X, d=d, qmin=qmin, qmax=qmax, maxit=maxit, epsconv=epsconv, output=list())

  
  for(k in qmin:qmax) {
    res$output[[k - qmin + 1]] <- gof_base(Y, X, k, d, maxit=maxit, epsconv=1e-8, directed=directed)
  }
  return(res)
}

gofNetwork<-function(Y, X, d, qmin, qmax, maxit=100, epsconv=1e-8, nbrepeat=1, ncores=1, directed=(sum(abs(Y-t(Y)))>0))  {
  
  registerDoMC(ncores) # register CPU cores for computing
  
  rgof<-list()
  inittabgof<-matrix(0, nbrepeat, qmax-qmin+1)
  
  rgof<-foreach(run=1:nbrepeat) %dopar% {
    gofK(Y, X, d, qmin, qmax, maxit=maxit, epsconv=epsconv, directed=directed)  
  }
  
  for(run in 1:nbrepeat) {
    inittabgof[run, ]<-unlist(lapply( rgof[[run]]$output, function(x) x$criterion)) 
  }
  
  idbest<-which(max(inittabgof) == inittabgof, arr.ind=TRUE)[1]
  
  res<-rgof[[idbest]]
  
  res$criterion <- inittabgof
  res$criterion_best <- inittabgof[idbest, ]
  if(!directed){
       Y<-Y*upper.tri(Y)
       Y[Y>1]<-1
  }
  res$edges = t(which(Y==1, arr.ind=TRUE))
  res$directed = directed
  
  class(res)<-"gofNetwork"
  return(res)
  
  
}
