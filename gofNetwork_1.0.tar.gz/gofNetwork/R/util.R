
# util.R 

class.ind<-function (cl)
{ 
  n <- length(cl)
  cl <- as.factor(cl)
  x <- matrix(0, n, length(levels(cl)))
  x[(1:n) + n * (unclass(cl) - 1)] <- 1
  dimnames(x) <- list(names(cl), levels(cl))
  x
}


graph.covariate.affiliation<-function(n, piVect=c(1/2,1/2), lambda=3, epsilon=-3, beta, X, directed=TRUE) {
  # generate an affiliation network with n nodes, K classes
  # PI : class proportions
  # alpha : class parameter matrix
  # beta : regression parameter vector
  # X : matrix of covariates

   K = length(piVect)

    
  if(K>1) {
    nq <- rmultinom(1, size = n, prob = piVect)
    Z <- class.ind(rep(1:K, nq))
    Z <- Z[sample(1:n, n), ]
  }
  else {
    if(K==1) {
      Z<-matrix(rep(1, n), n, 1)
    }
    else {
      stop("piVect must be a vector")
    }
  }
   alpha = matrix(epsilon, K, K)
   diag(alpha) = lambda

    
  Y<-matrix(0, n, n)
  if(directed) {
    for(i in 1:n) {
      for(j in 1:n) {
        if(i != j) {
          k<-which.max(Z[i, ])
          l<-which.max(Z[j, ])
          
          Y[i, j]<-rbinom(1, 1, plogis(alpha[k, l] + X[i, j, ]%*%beta))
        }
      }
    }
  }else {
    for(i in 1:(n-1)) {
      for(j in (i+1):n) {
        k<-which.max(Z[i, ])
        l<-which.max(Z[j, ])
        Y[i, j]<-rbinom(1, 1, plogis(alpha[k, l] + X[i, j, ]%*%beta))
        Y[j, i]<-Y[i, j]   
      }   
    }
  }
  
  return(list(Y=Y, X=X,cluster=apply(Z,1,which.max)))
  
}

computeProbBayes<-function(x, priorModel=c(1/2, rep(1/2, x$qmax-1)/(x$qmax-2+1))){
  if(x$qmin>1) {
    stop("computeProbBayes must be run with qmin=1")
  }
  if(is.gofNetwork(x)) {
    crit<-x$criterion_best
  }
  if(is.mixer(x)) {
    crit<-unlist(lapply(x$output, function(x) x$criterion))
  }
  post<-crit  + log(priorModel) 
  post<-post - max(post)
  post<-exp(post)
  post<-post/sum(post)
  PO<-post[1]/sum(post[-1])
  pH0_Y<-post[1]
  return(list(PO=PO, pH0_Y=pH0_Y, post=post))
}


is.gofNetwork<-function(x){if (class(x)=="gofNetwork") TRUE else FALSE}

is.mixer<-function(x){if (class(x)=="mixer") TRUE else FALSE}

getModel.gofNetwork<-function(res, q=NULL) {


  # Test input
  if ( !is.gofNetwork( res ) )
    stop("Not a gofNetwork object")
    
  if(!is.null(q)) {
    if((q < res$qmin) | (q > res$qmax)) {
    stop("q must between qmin and qmax")
    }
  }
  resmod<-list()
  resmod$Y = res$Y
  resmod$X = res$X
  resmod$d = res$d
  resmod$maxit = res$maxit
  resmod$epsconv = res$epsconv
 
  if(is.null(q)) {   
    # return the result for the value of q estimated
    crit<-unlist(lapply( res$output, function(x) x$criterion))
    best<-which.max(crit)
    q<- best + res$qmin - 1
  }
  resmod$q = q
  resmod$output = res$output[[q-res$qmin+1]]
  
  return(resmod)
}

