
vbem <- function(Y, X, n, K, d, Z, connect, xi, e0, a0, b0, c0, d0, maxit, epsconv) {

    .Call('gofNetwork_vbem', PACKAGE = 'gofNetwork', Y, X, n, K, d, Z, connect, xi, e0, a0, b0, c0, d0, maxit, epsconv)

}

vbemundirected <- function(Y, X, n, K, d, Z, connect, xi, e0, a0, b0, c0, d0, maxit, epsconv) {

    .Call('gofNetwork_vbemundirected', PACKAGE = 'gofNetwork', Y, X, n, K, d, Z, connect, xi, e0, a0, b0, c0, d0, maxit, epsconv)

}

